-- ============================================================
-- gbCorpus — actualización 31: los resultados regex pasan del formulario
--            modal a una pestaña
-- Esquema: 1
-- Origen: decisión de Alberto: FRegexResultados se reemplaza por la
--         pestaña «Resultados» de tsRegExp (índice 1), gobernada por un
--         módulo nuevo, m_RegexResultados. Sin el modal, las posiciones las
--         protege la regla de vigencia (snapshot mtime|size + HayCambios).
--         Cotejado con la carpeta local de gbCorpus (último script: act-30)
--         y con docs/corpus.md del repo de gbpublisher.
-- Fecha:  2026-10-14
--
-- MODIFICA:
--   SC-51  sección EL EDITOR MUESTRA LAS COINCIDENCIAS…: regla de vigencia,
--          pestaña en lugar de modal; pendiente ampliado; vínculos GV-47 y
--          RC-GM-16
--   GV-78  CASO EN EL PROYECTO (2): la grilla ahora es gvRegexResultados
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'SC-51 sección del modal', (length(cuerpo) - length(replace(cuerpo, 'EL EDITOR MUESTRA LAS COINCIDENCIAS Y SE RECARGA AL REEMPLAZAR (decisión de Alberto)

`FRegexResultados` es MODAL a propósito: mientras está abierto nadie escribe a mano en el editor. Con eso, el editor puede mostrar cualquier coincidencia sin riesgo de posiciones viejas.

- Antes de abrir el formulario, el editor tiene que ser igual al disco. El aviso de SC-06 ya pidió guardar o descartar, pero «Descartar» solo mueve el punto de control (`MarcarGuardado`): el texto descartado sigue en el editor. Si difiere del disco, `m_BuscarRegex.BuscarRegex` lo relee con `FMain.RecargarArchivoAbierto`.
- Un click en una fila de la grilla lleva el editor a la coincidencia (`m_BuscarRegex.MostrarCoincidencia`). Va en `Click`, no en `Select` (GV-78): la primera versión navegaba desde `Select` y el editor no cambiaba de archivo en Mint. El preview de `txtContexto` va en `Change`, que también sigue a las flechas: abre su archivo si no es el abierto (`m_Estructura.AbrirArchivo`, por el combo, GV-53) y la deja seleccionada con su párrafo arriba de la vista (`m_EditorPrincipal.IrA`, GV-52), por línea y columna base 0, como las da el script. «Resaltar» es seleccionar: colorear con `Format` entraría en el deshacer (GV-46). Medido en banco: la selección se ve con el modal encima. No hace falta desplazar el editor a mano: el párrafo queda arriba.
- Después de escribir, `FRegexResultados` llama en el acto a `m_BuscarRegex.TrasReemplazo` con los archivos efectivamente escritos, también si la escritura se cortó a mitad. Para cada uno: árbol de estructura y referencias citadas en la base (`m_Bibtex.ExtraerYGuardarReferenciasDelEditor`), lo mismo que hace un guardado. Si uno es el abierto: `FMain.RecargarArchivoAbierto` (editor, árbol, comentarios y contador). Después se vuelve a buscar, así que las posiciones de la grilla vuelven a valer.
- Recargar es el punto de refresco 2 de SC-18: corta el deshacer. No se pierde nada: lo escrito por el reemplazo se deshace con git, que el guard del formulario exige o advierte.
- Después de reemplazar, el editor queda en el ÚLTIMO archivo cambiado (orden de la grilla, que es el editorial), con su PRIMER cambio seleccionado y el párrafo arriba (decisión de Alberto). Ese cambio no se corrió: los reemplazos van de atrás para adelante. Al volver a llenar la grilla, el editor no se mueve: la navegación cuelga de `Click`, que el código nunca dispara (GV-78). La bandera `$bRepoblando` solo evita que el preview se actualice con una fila movida por el código.
- Al cerrar, el editor queda donde estaba —la última coincidencia vista o el último cambio—, con el foco.
- `MostrarCoincidencia` no tiene salidas mudas (GV-23): si no puede mover el editor, lo dice.

', ''))) / length('EL EDITOR MUESTRA LAS COINCIDENCIAS Y SE RECARGA AL REEMPLAZAR (decisión de Alberto)

`FRegexResultados` es MODAL a propósito: mientras está abierto nadie escribe a mano en el editor. Con eso, el editor puede mostrar cualquier coincidencia sin riesgo de posiciones viejas.

- Antes de abrir el formulario, el editor tiene que ser igual al disco. El aviso de SC-06 ya pidió guardar o descartar, pero «Descartar» solo mueve el punto de control (`MarcarGuardado`): el texto descartado sigue en el editor. Si difiere del disco, `m_BuscarRegex.BuscarRegex` lo relee con `FMain.RecargarArchivoAbierto`.
- Un click en una fila de la grilla lleva el editor a la coincidencia (`m_BuscarRegex.MostrarCoincidencia`). Va en `Click`, no en `Select` (GV-78): la primera versión navegaba desde `Select` y el editor no cambiaba de archivo en Mint. El preview de `txtContexto` va en `Change`, que también sigue a las flechas: abre su archivo si no es el abierto (`m_Estructura.AbrirArchivo`, por el combo, GV-53) y la deja seleccionada con su párrafo arriba de la vista (`m_EditorPrincipal.IrA`, GV-52), por línea y columna base 0, como las da el script. «Resaltar» es seleccionar: colorear con `Format` entraría en el deshacer (GV-46). Medido en banco: la selección se ve con el modal encima. No hace falta desplazar el editor a mano: el párrafo queda arriba.
- Después de escribir, `FRegexResultados` llama en el acto a `m_BuscarRegex.TrasReemplazo` con los archivos efectivamente escritos, también si la escritura se cortó a mitad. Para cada uno: árbol de estructura y referencias citadas en la base (`m_Bibtex.ExtraerYGuardarReferenciasDelEditor`), lo mismo que hace un guardado. Si uno es el abierto: `FMain.RecargarArchivoAbierto` (editor, árbol, comentarios y contador). Después se vuelve a buscar, así que las posiciones de la grilla vuelven a valer.
- Recargar es el punto de refresco 2 de SC-18: corta el deshacer. No se pierde nada: lo escrito por el reemplazo se deshace con git, que el guard del formulario exige o advierte.
- Después de reemplazar, el editor queda en el ÚLTIMO archivo cambiado (orden de la grilla, que es el editorial), con su PRIMER cambio seleccionado y el párrafo arriba (decisión de Alberto). Ese cambio no se corrió: los reemplazos van de atrás para adelante. Al volver a llenar la grilla, el editor no se mueve: la navegación cuelga de `Click`, que el código nunca dispara (GV-78). La bandera `$bRepoblando` solo evita que el preview se actualice con una fila movida por el código.
- Al cerrar, el editor queda donde estaba —la última coincidencia vista o el último cambio—, con el foco.
- `MostrarCoincidencia` no tiene salidas mudas (GV-23): si no puede mover el editor, lo dice.

') = 1 FROM entradas WHERE codigo = 'SC-51';
INSERT INTO verificacion SELECT 'SC-51 pendiente', (length(pendiente) - length(replace(pendiente, 'Después, quitar este pendiente y poner el entorno de Mint.', ''))) / length('Después, quitar este pendiente y poner el entorno de Mint.') = 1 FROM entradas WHERE codigo = 'SC-51';
INSERT INTO verificacion SELECT 'SC-51 sin GV-47 ni RC-GM-16', instr(relaciones, 'GV-47') = 0 AND instr(relaciones, 'RC-GM-16') = 0 FROM entradas WHERE codigo = 'SC-51';
INSERT INTO verificacion SELECT 'GV-78 caso (2)', (length(cuerpo) - length(replace(cuerpo, 'CASO EN EL PROYECTO (2): `FRegexResultados`, que es `Select.Multiple` para elegir qué reemplazar, navegaba desde `gvResultados_Select` y en Mint el editor no cambiaba de archivo. Pasó a `gvResultados_Click`, con el preview en `gvResultados_Change` (SC-51).', ''))) / length('CASO EN EL PROYECTO (2): `FRegexResultados`, que es `Select.Multiple` para elegir qué reemplazar, navegaba desde `gvResultados_Select` y en Mint el editor no cambiaba de archivo. Pasó a `gvResultados_Click`, con el preview en `gvResultados_Change` (SC-51).') = 1 FROM entradas WHERE codigo = 'GV-78';

-- ------------------------------------------------------------
-- 2. SC-51
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'EL EDITOR MUESTRA LAS COINCIDENCIAS Y SE RECARGA AL REEMPLAZAR (decisión de Alberto)

`FRegexResultados` es MODAL a propósito: mientras está abierto nadie escribe a mano en el editor. Con eso, el editor puede mostrar cualquier coincidencia sin riesgo de posiciones viejas.

- Antes de abrir el formulario, el editor tiene que ser igual al disco. El aviso de SC-06 ya pidió guardar o descartar, pero «Descartar» solo mueve el punto de control (`MarcarGuardado`): el texto descartado sigue en el editor. Si difiere del disco, `m_BuscarRegex.BuscarRegex` lo relee con `FMain.RecargarArchivoAbierto`.
- Un click en una fila de la grilla lleva el editor a la coincidencia (`m_BuscarRegex.MostrarCoincidencia`). Va en `Click`, no en `Select` (GV-78): la primera versión navegaba desde `Select` y el editor no cambiaba de archivo en Mint. El preview de `txtContexto` va en `Change`, que también sigue a las flechas: abre su archivo si no es el abierto (`m_Estructura.AbrirArchivo`, por el combo, GV-53) y la deja seleccionada con su párrafo arriba de la vista (`m_EditorPrincipal.IrA`, GV-52), por línea y columna base 0, como las da el script. «Resaltar» es seleccionar: colorear con `Format` entraría en el deshacer (GV-46). Medido en banco: la selección se ve con el modal encima. No hace falta desplazar el editor a mano: el párrafo queda arriba.
- Después de escribir, `FRegexResultados` llama en el acto a `m_BuscarRegex.TrasReemplazo` con los archivos efectivamente escritos, también si la escritura se cortó a mitad. Para cada uno: árbol de estructura y referencias citadas en la base (`m_Bibtex.ExtraerYGuardarReferenciasDelEditor`), lo mismo que hace un guardado. Si uno es el abierto: `FMain.RecargarArchivoAbierto` (editor, árbol, comentarios y contador). Después se vuelve a buscar, así que las posiciones de la grilla vuelven a valer.
- Recargar es el punto de refresco 2 de SC-18: corta el deshacer. No se pierde nada: lo escrito por el reemplazo se deshace con git, que el guard del formulario exige o advierte.
- Después de reemplazar, el editor queda en el ÚLTIMO archivo cambiado (orden de la grilla, que es el editorial), con su PRIMER cambio seleccionado y el párrafo arriba (decisión de Alberto). Ese cambio no se corrió: los reemplazos van de atrás para adelante. Al volver a llenar la grilla, el editor no se mueve: la navegación cuelga de `Click`, que el código nunca dispara (GV-78). La bandera `$bRepoblando` solo evita que el preview se actualice con una fila movida por el código.
- Al cerrar, el editor queda donde estaba —la última coincidencia vista o el último cambio—, con el foco.
- `MostrarCoincidencia` no tiene salidas mudas (GV-23): si no puede mover el editor, lo dice.

', 'EL EDITOR MUESTRA LAS COINCIDENCIAS Y SE RECARGA AL REEMPLAZAR (decisión de Alberto)

Los resultados viven en la pestaña «Resultados» de `tsRegExp` (índice 1), al lado del banco de pruebas (índice 0). La gobierna `m_RegexResultados`; `m_BuscarRegex.BuscarRegex` le pasa los archivos, el patrón, el reemplazo y los flags ya resueltos. La primera versión era un formulario modal, `FRegexResultados`: mientras estaba abierto nadie escribía en el editor y por eso las posiciones no podían quedar viejas. La pestaña no es modal, y esa garantía la da la regla de vigencia.

REGLA DE VIGENCIA

Las coincidencias de un archivo siguen valiendo si su firma `mtime|size` es la capturada antes de lanzar perl (snapshot de todos los archivos buscados) y, si es el archivo abierto, `m_EditorPrincipal.HayCambios()` da `False`. Con eso, el disco es el que leyó perl y el editor es igual al disco.

- Se verifica antes de saltar desde la grilla y, para todos los archivos afectados, antes de escribir. Si falla, no se salta ni se escribe nada: se avisa y se vuelve a buscar, con el aviso de SC-06 y el editor igual al disco.
- La verificación de escritura va después del guard de git, lo más cerca posible de la escritura. Sin ella, la recarga posterior (`FMain.RecargarArchivoAbierto`) se llevaría puestos los cambios sin guardar del editor.
- No se compara el texto en el offset contra el campo «antes» del script: `.Text` normaliza el espacio duro (GV-47) y la comparación fallaría siempre.
- Una búsqueda por vez. Buscar con otra en curso pide esperar o cancelar. No se cancela y se relanza en el acto: el `Kill` del proceso viejo llega más tarde como evento y se tomaría como el fin del nuevo.
- Al abrir o cerrar un proyecto, `m_RegexResultados.InicializarTab` corta el perl que corra y vacía la grilla (RC-GM-16).

EL EDITOR Y LA GRILLA

- Antes de buscar, el editor tiene que ser igual al disco. El aviso de SC-06 ya pidió guardar o descartar, pero «Descartar» solo mueve el punto de control (`MarcarGuardado`): el texto descartado sigue en el editor. Si difiere del disco, `m_BuscarRegex.BuscarRegex` lo relee con `FMain.RecargarArchivoAbierto`. Es la condición de partida de la regla de vigencia.
- Un click en una fila de la grilla lleva el editor a la coincidencia (`m_BuscarRegex.MostrarCoincidencia`): abre su archivo si no es el abierto (`m_Estructura.AbrirArchivo`, por el combo, GV-53) y la deja seleccionada con su párrafo arriba de la vista (`m_EditorPrincipal.IrA`, GV-52), por línea y columna base 0, como las da el script. Va en `Click`, no en `Select` (GV-78): la primera versión navegaba desde `Select` y el editor no cambiaba de archivo en Mint. «Resaltar» es seleccionar: colorear con `Format` entraría en el deshacer (GV-46). El foco queda en la grilla: el usuario recorre resultados y elige filas, no escribe.
- El preview de `txaRegexContexto` va en `Change`, que también sigue a las flechas, y no mueve el editor.
- Después de escribir, `m_RegexResultados.Reemplazar` llama en el acto a `m_BuscarRegex.TrasReemplazo` con los archivos efectivamente escritos, también si la escritura se cortó a mitad. Para cada uno: árbol de estructura y referencias citadas en la base (`m_Bibtex.ExtraerYGuardarReferenciasDelEditor`), lo mismo que hace un guardado. Si uno es el abierto: `FMain.RecargarArchivoAbierto` (editor, árbol, comentarios y contador). Después se vuelve a buscar, con snapshot nuevo, así que las posiciones de la grilla vuelven a valer.
- Recargar es el punto de refresco 2 de SC-18: corta el deshacer. No se pierde nada: lo escrito por el reemplazo se deshace con git, que el guard exige o advierte.
- Después de reemplazar, el editor queda en el ÚLTIMO archivo cambiado (orden de la grilla, que es el editorial), con su PRIMER cambio seleccionado y el párrafo arriba (decisión de Alberto). Ese cambio no se corrió: los reemplazos van de atrás para adelante. Al volver a llenar la grilla, el editor no se mueve: la navegación cuelga de `Click`, que el código nunca dispara (GV-78). La bandera `$bRepoblando` solo evita que el preview se actualice con una fila movida por el código.
- `btnRegexCancelar` se habilita solo mientras se busca; `btnRegexReemplazar`, solo con reemplazo escrito, sin búsqueda en curso y con coincidencias.
- `MostrarCoincidencia` no tiene salidas mudas (GV-23): si no puede mover el editor, lo dice. No verifica la posición: lo hace quien la llama.

'),
       pendiente = replace(pendiente, 'Después, quitar este pendiente y poner el entorno de Mint.', 'Después, quitar este pendiente y poner el entorno de Mint. Probar también en Mint el pasaje a la pestaña: click después de editar sin guardar y después de guardar (los dos vuelven a buscar), reemplazar con el abierto modificado (no escribe), cancelar, y cerrar el proyecto con una búsqueda en curso.'),
       relaciones = relaciones || ',vinculo:GV-47,vinculo:RC-GM-16',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-51';
INSERT INTO verificacion SELECT 'SC-51 actualizada', instr(cuerpo, 'REGLA DE VIGENCIA') > 0 AND instr(cuerpo, 'es MODAL a propósito') = 0 AND instr(pendiente, 'pasaje a la pestaña') > 0 FROM entradas WHERE codigo = 'SC-51';

-- ------------------------------------------------------------
-- 3. GV-78
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'CASO EN EL PROYECTO (2): `FRegexResultados`, que es `Select.Multiple` para elegir qué reemplazar, navegaba desde `gvResultados_Select` y en Mint el editor no cambiaba de archivo. Pasó a `gvResultados_Click`, con el preview en `gvResultados_Change` (SC-51).', 'CASO EN EL PROYECTO (2): la grilla de resultados regex, que es `Select.Multiple` para elegir qué reemplazar, navegaba desde `Select` cuando era el formulario `FRegexResultados`, y en Mint el editor no cambiaba de archivo. Pasó a `Click`, con el preview en `Change`. Hoy es `FMain.gvRegexResultados`, gobernada por `m_RegexResultados` (SC-51).'),
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'GV-78';
INSERT INTO verificacion SELECT 'GV-78 actualizada', instr(cuerpo, 'gvRegexResultados') > 0 AND instr(cuerpo, 'gvResultados_Select') = 0 FROM entradas WHERE codigo = 'GV-78';

COMMIT;

SELECT codigo, estado, titulo FROM entradas WHERE codigo IN ('SC-51', 'GV-78') ORDER BY prefijo, numero;
